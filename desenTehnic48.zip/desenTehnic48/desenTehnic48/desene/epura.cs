﻿/*
 * Created by SharpDevelop.
 * User: razvan
 * Date: 5/19/2024
 * Time: 6:07 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace desenTehnic48
{
	/// <summary>
	/// Description of epura.
	/// </summary>
	public class epura
	{
		public epura()
		{
		}
	}
}
