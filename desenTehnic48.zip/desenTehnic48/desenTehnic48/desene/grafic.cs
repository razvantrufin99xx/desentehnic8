﻿/*
 * Created by SharpDevelop.
 * User: razvan
 * Date: 5/19/2024
 * Time: 5:57 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace desenTehnic48
{
	/// <summary>
	/// Description of grafic.
	/// </summary>
	public class grafic
	{
		public grafic()
		{
		}
	}
}
