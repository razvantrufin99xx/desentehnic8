﻿/*
 * Created by SharpDevelop.
 * User: razvan
 * Date: 5/25/2024
 * Time: 9:57 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace desenTehnic48.forme
{
	/// <summary>
	/// Description of shape.
	/// </summary>
	public class shape
	{
			public string TIP = "SHAPE";
			public  utile.dimensiune d= new  utile.dimensiune();
			public  utile.stil s = new  utile.stil();
			public  utile.pozitie p = new  utile.pozitie();
			public List< utile.pair> shapedots = new List< utile.pair>();
			public void draw(ref Graphics pg,ref desene.desen pd, string tip)
			{
				pd.draw(ref pg, ref pd,ref tip, this);
			}
			public void draw(ref Graphics pg,desene.desen pd, string tip)
			{
				pd.draw(ref pg, ref pd,ref tip, this);
			}
			
		public shape()
		{
		}
	}
}
