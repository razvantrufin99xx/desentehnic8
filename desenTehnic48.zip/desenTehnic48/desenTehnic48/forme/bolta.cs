﻿/*
 * Created by SharpDevelop.
 * User: razvan
 * Date: 5/19/2024
 * Time: 6:06 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace desenTehnic48
{
	/// <summary>
	/// Description of bolta.
	/// </summary>
	public class bolta
	{
		public bolta()
		{
		}
	}
}
