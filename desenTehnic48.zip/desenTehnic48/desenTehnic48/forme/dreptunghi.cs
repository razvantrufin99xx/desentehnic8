﻿/*
 * Created by SharpDevelop.
 * User: razvan
 * Date: 5/19/2024
 * Time: 6:33 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace desenTehnic48.forme
{
	/// <summary>
	/// Description of dreptunghi.
	/// </summary>
	public class dreptunghi
	{
		public dreptunghi()
		{
		}
	}
}
