﻿/*
 * Created by SharpDevelop.
 * User: razvan
 * Date: 5/19/2024
 * Time: 6:39 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace desenTehnic48.utile
{
	/// <summary>
	/// Description of pozitie3d.
	/// </summary>
	public class pozitie3d
	{
		public float x;
		public float y;
		public float z;
	
		public pozitie3d()
		{
		}
	}
}
