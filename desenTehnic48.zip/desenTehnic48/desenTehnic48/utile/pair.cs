﻿/*
 * Created by SharpDevelop.
 * User: razvan
 * Date: 5/25/2024
 * Time: 9:57 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
namespace desenTehnic48.utile
{
	/// <summary>
	/// Description of pair.
	/// </summary>
	public class pair
	{
		public float a;
			public float b;
		public pair()
		{
		}
	}
}
