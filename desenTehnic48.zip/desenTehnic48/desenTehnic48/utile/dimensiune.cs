﻿/*
 * Created by SharpDevelop.
 * User: razvan
 * Date: 5/19/2024
 * Time: 6:01 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
namespace desenTehnic48.utile
{
	/// <summary>
	/// Description of dimensiune.
	/// </summary>
	public class dimensiune
	{
		public float w;
		public float h;
			
		public dimensiune()
		{
			
		}
	}
}
