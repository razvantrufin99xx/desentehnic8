﻿/*
 * Created by SharpDevelop.
 * User: razvan
 * Date: 5/19/2024
 * Time: 6:03 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace desenTehnic48
{
	/// <summary>
	/// Description of punct3d.
	/// </summary>
	public class punct3d
	{
		public utile.pozitie3d pozitia3d;
		
		public punct3d()
		{
		}
	}
}
