﻿/*
 * Created by SharpDevelop.
 * User: razvan
 * Date: 5/19/2024
 * Time: 5:59 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace desenTehnic48
{
	/// <summary>
	/// Description of florar.
	/// </summary>
	public class florar
	{
		public florar()
		{
		}
	}
}
