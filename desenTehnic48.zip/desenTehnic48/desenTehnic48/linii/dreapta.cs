﻿/*
 * Created by SharpDevelop.
 * User: razvan
 * Date: 5/19/2024
 * Time: 6:33 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace desenTehnic48.linii
{
	/// <summary>
	/// Description of dreapta.
	/// </summary>
	public class dreapta
	{
		public dreapta()
		{
		}
	}
}
